
const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

function adicionarAoCarrinho(nome, preco) {
  carrinho.push({ nome, preco });
  localStorage.setItem('carrinho', JSON.stringify(carrinho));
  alert(`${nome} adicionado ao carrinho!`);
}

if (document.getElementById("carrinho-itens")) {
  const container = document.getElementById("carrinho-itens");
  let total = 0;
  carrinho.forEach((item) => {
    const div = document.createElement("div");
    div.innerText = `${item.nome} - ${item.preco}`;
    container.appendChild(div);
    total += parseFloat(item.preco.replace("R$", "").replace(",", "."));
  });
  document.getElementById("total").innerText = "Total: R$ " + total.toFixed(2).replace(".", ",");
}
